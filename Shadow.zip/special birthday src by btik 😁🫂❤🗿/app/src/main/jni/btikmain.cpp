//Birthday special source code of free fire mod menu by B-tik 🙏❤️😴
//leaked from india by b-tik on 13th october 11.20 p.m.🗿🌚🥲
//please dont take the credits to and share with my credits brother and sisters 😊❤️🫂

//Birthday special source code of free fire mod menu by B-tik 🙏❤️😴
//leaked from india by b-tik on 13th october 11.20 p.m.🗿🌚🥲
//please dont take the credits to and share with my credits brother and sisters 😊❤️🫂

//Birthday special source code of free fire mod menu by B-tik 🙏❤️😴
//leaked from india by b-tik on 13th october 11.20 p.m.🗿🌚🥲
//please dont take the credits to and share with my credits brother and sisters 😊❤️🫂

//Birthday special source code of free fire mod menu by B-tik 🙏❤️😴
//leaked from india by b-tik on 13th october 11.20 p.m.🗿🌚🥲
//please dont take the credits to and share with my credits brother and sisters 😊❤️🫂

#include <android/log.h>
#include <unistd.h>
#include <thread>
#include <limits>
#include <ctime>
#include <cstring>
#include <cstdio>
#include <cstdint>
#include <cstdlib>
#include <cmath>
#include <dlfcn.h>
#include <sys/mman.h>
#include <xdl.h>
#include <KittyUtils.h>
#include <KittyMemory.h>
#include <KittyMemory/MemoryPatch.h>
#include <Il2Cpp.h>
#include <SubstrateHook.h>
#include <CydiaSubstrate.h>

#include "BTIK MODS/Gui.hpp"
#include "BTIK MODS/main.h"
#include "fonts/FontAwesome6_solid.h"


#include "BTIK MODS/firewall.h"

///Birthday special source code of free fire mod menu by B-tik 🙏❤️😴
//leaked from india by b-tik on 13th october 11.20 p.m.🗿🌚🥲
//please dont take the credits to and share with my credits brother and sisters 😊❤️🫂

void hack_thread();

bool  EnableSmartAimbot   = false;
bool  SpeedHack           = false;
bool  RenderWatermark     = true;
bool  menu1 = false, menu2 = false, menu3 = false, menu4 = false;
bool  showWatermark       = true;
bool  rPritam             = false;
bool  TPBR                = false;
bool  Pritamaim           = false;
bool  PritamAimbot        = false;
bool  Reset               = false;
bool  Guest               = false;
bool  camxa               = false;
bool  SniperFast          = false;
bool  PcSwapAnim          = false;
bool  Setindia            = false;
bool  Fastswitch          = false;
bool  AutoRun             = false;
bool  InfiniteRange       = false;
bool  speedrun            = false;
bool  isSpeed             = false;
bool  Firewall            = true;
bool  health              = false;
bool  AimNewF             = true;
bool  ESPLine             = false;
bool  ESPBox              = false;
bool  EspBox3d            = false;
bool  SniperAlert         = false;
bool  SelectAim           = true;
bool  AimBody             = false;
bool  showAlert           = false;
bool  DrawFov             = false;
bool  ShubhHuRe           = false;
bool  Garena_ki_mkc       = false;
bool  ESPGrenade          = false;
bool  AimEnable           = false;
bool  AimWhen1 = false, AimWhen2 = false, AimWhen3 = false;
bool  camcao              = false;
bool  box                 = false;
bool  showbox1            = false;
bool  showline1           = false;
bool  showline2           = false;
bool  showline            = false;
bool  norecoil            = false;
bool  isParachuting       = false;
bool  MedkitMoving        = false;
bool  FreeMove            = false;
bool  StopFireAnim        = false;
bool  FastSensivity       = false;
bool  ShurikenKill        = false;
bool  AutoKill            = false;
bool  AimKill1            = false;
bool  AimKillIgnoreVisible = false;
bool  AimKillHeadOnly     = true;
bool  AimLock             = false;
bool  AimLockThroughWall  = false;
bool  CustomFireRate      = false;
bool  SpinBot             = false;
bool  autoReviveEnabled   = false;
bool  gliderHackEnabled   = false;
bool  gliderInfiniteEnabled = false;
bool  aimVisibleEnabled   = false;
bool  QuickReloadLakiyaxMods = false;
bool  LUNDUP              = true;
bool  FUCKMODI            = false;
bool  EnableNightMode     = false;
bool  EspSkeleton2        = false;
bool  ANTIDEV             = false;
bool  SpoofNameEnabled    = true;

float AutoKillDelayMs     = 100.0f;
float AimKillFov          = 500.0f;
float AimKillDistance     = 100.0f;
float AimLockFov          = 200.0f;
float AimLockSpeed        = 0.15f;
float FireRateMs          = 100.0f;
float ShotsPerBurst       = 1.0f;
float SpinBotSpeed        = 720.0f;
float aimVisibleFov       = 200.0f;
float aimVisibleMaxDist   = 200.0f;
float FUCKMODIRate        = 0.90f;
float Sensivity           = 1.0f;
float AiFov               = 15.0f;
float AimSpeed            = 0.1f;
float NECK_OFFSET         = -0.15f;
float LineThickness       = 2.0f;
float BoxThickness        = 2.0f;
float BoxRoundness        = 0.0f;
float RGBSpeed            = 1.0f;

int   SetDamage           = 1;
int   LineMode            = 0;
int   BoxStyle            = 0;
int   FovStyle            = 0;
int   HealthBoxStyle      = 0;
int   DONTCarValue        = 0;
int   damageCooldown      = 0;
int   delayCounter        = 0;
int   delayLimit          = 2;
int   delayLimit2         = 0;
int   DamageDelay         = 2;
int   aimPosition         = 0;
int   Fov_Aim_Old         = 360;
float Aimdis_Old          = 500.0f;
bool  aimVisibleIgnoreKnocked = true;

void* enemyTarget         = nullptr;
void* LockedEnemy         = nullptr;
float LockedEnemyTime     = 0.0f;
float lastFireTime        = 0.0f;
float lastAutoKillTime    = 0.0f;

bool  Startgs             = true;
void* mainCamera          = nullptr;
ImVec4 ThemeColer         = ImVec4(0.00f, 1.00f, 0.97f, 1.00f);

MassKill Mass;


bool AimHead35 = true, AimHead50 = false, AimHead75 = false, AimHead90 = false, AimHead100 = false;


bool g_LoginBypass400 = false;

//Birthday special source code of free fire mod menu by B-tik 🙏❤️😴
//leaked from india by b-tik on 13th october 11.20 p.m.🗿🌚🥲
//please dont take the credits to and share with my credits brother and sisters 😊❤️🫂

static bool  g_MenuOpen      = true;
static float g_FloatBtnX     = 60.0f;
static float g_FloatBtnY     = 200.0f;
static bool  g_FloatDragging = false;
static float g_DragOffsetX   = 0.0f;
static float g_DragOffsetY   = 0.0f;

//Birthday special source code of free fire mod menu by B-tik 🙏❤️😴
//leaked from india by b-tik on 13th october 11.20 p.m.🗿🌚🥲
//please dont take the credits to and share with my credits brother and sisters 😊❤️🫂

static float currentWidth  = 720.0f;
static float currentHeight = 500.0f;
static int   currentTab    = 0;
bool ImGuiOK = true;


namespace CyberTheme {
    ImVec4 BgDeep       = ImVec4(0.039f, 0.055f, 0.078f, 1.00f);
    ImVec4 BgPanel      = ImVec4(0.059f, 0.078f, 0.106f, 1.00f);
    ImVec4 BgChild      = ImVec4(0.075f, 0.098f, 0.129f, 1.00f);
    ImVec4 NeonCyan     = ImVec4(0.000f, 1.000f, 0.969f, 1.00f);
    ImVec4 NeonMagenta  = ImVec4(1.000f, 0.000f, 0.800f, 1.00f);
    ImVec4 MatrixGreen  = ImVec4(0.000f, 1.000f, 0.616f, 1.00f);
    ImVec4 Amber        = ImVec4(1.000f, 0.702f, 0.278f, 1.00f);
    ImVec4 TextPri      = ImVec4(0.910f, 0.945f, 0.980f, 1.00f);
    ImVec4 TextDim      = ImVec4(0.478f, 0.518f, 0.573f, 1.00f);
    ImVec4 Border       = ImVec4(0.000f, 1.000f, 0.969f, 0.35f);
    ImVec4 Danger       = ImVec4(1.000f, 0.180f, 0.333f, 1.00f);
    ImVec4 Success      = ImVec4(0.000f, 1.000f, 0.616f, 1.00f);
}


static uintptr_t lib_base(const char* name) {
    if (!name) return 0;
    FILE* f = fopen("/proc/self/maps", "r");
    if (!f) return 0;
    char line[512];
    uintptr_t base = 0;
    while (fgets(line, sizeof(line), f)) {
        uintptr_t start, end;
        char perms[8];
        char path[256];
        if (sscanf(line, "%lx-%lx %7s %*s %*s %*s %255s",
                   &start, &end, perms, path) != 4)
            continue;
        if (strstr(path, name)) { base = start; break; }
    }
    fclose(f);
    return base;
}

static bool mem_write(uintptr_t addr, const uint8_t* data, size_t len) {
    if (!addr || !data || !len) return false;
    long pg = sysconf(_SC_PAGESIZE);
    uintptr_t page = addr & ~(uintptr_t)(pg - 1);
    size_t span = (addr + len - page + pg - 1) & ~(size_t)(pg - 1);
    if (mprotect((void*)page, span, PROT_READ | PROT_WRITE | PROT_EXEC) != 0)
        return false;
    memcpy((void*)addr, data, len);
    __builtin___clear_cache((char*)addr, (char*)(addr + len));
    mprotect((void*)page, span, PROT_READ | PROT_EXEC);
    return true;
}

static bool patch_hex(uintptr_t base, uintptr_t off, const char* hex) {
    if (!base || !hex) return false;
    uint8_t buf[64]; size_t n = 0;
    auto nib = [](char c)->int{
        if (c >= '0' && c <= '9') return c - '0';
        if (c >= 'a' && c <= 'f') return c - 'a' + 10;
        if (c >= 'A' && c <= 'F') return c - 'A' + 10;
        return -1;
    };
    for (const char* p = hex; *p && n < sizeof(buf);) {
        while (*p == ' ') ++p;
        if (!*p) break;
        int hi = nib(p[0]), lo = nib(p[1]);
        if (hi < 0 || lo < 0) return false;
        buf[n++] = (uint8_t)((hi << 4) | lo);
        p += 2;
    }
    return mem_write(base + off, buf, n);
}

#define PATCH_LIB(lib, off, hex) \
    do { \
        uintptr_t _b = lib_base(lib); \
        if (_b) patch_hex(_b, (uintptr_t)(off), hex); \
    } while (0)

//Birthday special source code of free fire mod menu by B-tik 🙏❤️😴
//leaked from india by b-tik on 13th october 11.20 p.m.🗿🌚🥲
//please dont take the credits to and share with my credits brother and sisters 😊❤️🫂

void OpenURL(Il2CppString* url) {
    if (!url) return;
    typedef void (*Application_OpenURL_ftn)(Il2CppString*);
    static Application_OpenURL_ftn open_url = nullptr;
    if (!open_url) {
        void* methodOffset = Il2CppGetMethodOffset(
            OBFUSCATE("UnityEngine.CoreModule.dll"),
            OBFUSCATE("UnityEngine"),
            OBFUSCATE("Application"),
            OBFUSCATE("OpenURL"),
            1
        );
        if (methodOffset) open_url = (Application_OpenURL_ftn)methodOffset;
    }
    if (open_url) open_url(url);
}

//Birthday special source code of free fire mod menu by B-tik 🙏❤️😴
//leaked from india by b-tik on 13th october 11.20 p.m.🗿🌚🥲
//please dont take the credits to and share with my credits brother and sisters 😊❤️🫂

JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM *vm, void *reserved) {
    jvm = vm;
    std::thread(hack_thread).detach();
    return JNI_VERSION_1_6;
}

//Birthday special source code of free fire mod menu by B-tik 🙏❤️😴
//leaked from india by b-tik on 13th october 11.20 p.m.🗿🌚🥲
//please dont take the credits to and share with my credits brother and sisters 😊❤️🫂

void ApplyCyberTheme() {
    ImGuiStyle *s = &ImGui::GetStyle();
    s->WindowPadding      = ImVec2(14, 14);
    s->WindowRounding     = 10.0f;
    s->WindowBorderSize   = 1.0f;
    s->FramePadding       = ImVec2(12, 8);
    s->FrameRounding      = 6.0f;
    s->ItemSpacing        = ImVec2(10, 10);
    s->ItemInnerSpacing   = ImVec2(8, 6);
    s->ChildRounding      = 8.0f;
    s->PopupRounding      = 6.0f;
    s->ScrollbarRounding  = 6.0f;
    s->GrabRounding       = 6.0f;
    s->TabRounding        = 6.0f;

    ImVec4* c = s->Colors;
    c[ImGuiCol_WindowBg]        = CyberTheme::BgPanel;
    c[ImGuiCol_ChildBg]         = CyberTheme::BgChild;
    c[ImGuiCol_PopupBg]         = CyberTheme::BgPanel;
    c[ImGuiCol_Border]          = CyberTheme::Border;
    c[ImGuiCol_Text]            = CyberTheme::TextPri;
    c[ImGuiCol_TextDisabled]    = CyberTheme::TextDim;
    c[ImGuiCol_FrameBg]         = ImVec4(0.09f, 0.11f, 0.15f, 1.0f);
    c[ImGuiCol_FrameBgHovered]  = ImVec4(0.11f, 0.15f, 0.20f, 1.0f);
    c[ImGuiCol_FrameBgActive]   = ImVec4(0.13f, 0.18f, 0.24f, 1.0f);
    c[ImGuiCol_Button]          = ImVec4(0.00f, 0.60f, 0.58f, 1.0f);
    c[ImGuiCol_ButtonHovered]   = CyberTheme::NeonCyan;
    c[ImGuiCol_ButtonActive]    = ImVec4(0.00f, 0.80f, 0.75f, 1.0f);
    c[ImGuiCol_CheckMark]       = CyberTheme::NeonCyan;
    c[ImGuiCol_SliderGrab]      = CyberTheme::NeonCyan;
    c[ImGuiCol_SliderGrabActive]= CyberTheme::NeonMagenta;
    c[ImGuiCol_Header]          = ImVec4(0.00f, 0.80f, 0.75f, 0.30f);
    c[ImGuiCol_HeaderHovered]   = ImVec4(0.00f, 1.00f, 0.97f, 0.50f);
    c[ImGuiCol_HeaderActive]    = ImVec4(0.00f, 1.00f, 0.97f, 0.80f);
    c[ImGuiCol_Tab]             = ImVec4(0.07f, 0.09f, 0.12f, 1.0f);
    c[ImGuiCol_TabHovered]      = ImVec4(0.00f, 0.80f, 0.75f, 0.60f);
    c[ImGuiCol_TabActive]       = ImVec4(0.00f, 0.60f, 0.58f, 1.0f);
    c[ImGuiCol_ScrollbarBg]     = ImVec4(0.05f, 0.07f, 0.09f, 1.0f);
    c[ImGuiCol_ScrollbarGrab]   = CyberTheme::NeonCyan;
}

//Birthday special source code of free fire mod menu by B-tik 🙏❤️😴
//leaked from india by b-tik on 13th october 11.20 p.m.🗿🌚🥲
//please dont take the credits to and share with my credits brother and sisters 😊❤️🫂

bool CyberSlider(const char* label, float* value, float min, float max,
                 const char* fmt = "%.2f") {
    if (!value) return false;

    ImGui::PushID(label);

    ImGui::TextColored(CyberTheme::TextDim, "%s", label);
    ImGui::SameLine();
    ImGui::TextColored(CyberTheme::NeonCyan, fmt, *value);

    float width = ImGui::GetContentRegionAvail().x;
    ImVec2 pos  = ImGui::GetCursorScreenPos();
    ImDrawList* dl = ImGui::GetWindowDrawList();

    ImGui::InvisibleButton("##sldr", ImVec2(width, 24));
    bool changed = false;
    if (ImGui::IsItemActive()) {
        float t = (ImGui::GetIO().MousePos.x - pos.x) / width;
        t = ImClamp(t, 0.0f, 1.0f);
        *value = min + (max - min) * t;
        changed = true;
    }

    float fraction = (*value - min) / (max - min);
    float knobX = pos.x + width * fraction;
    float cy    = pos.y + 12.0f;

    dl->AddRectFilled(ImVec2(pos.x, pos.y + 9),
                      ImVec2(pos.x + width, pos.y + 15),
                      IM_COL32(15, 20, 28, 255), 8.0f);
    dl->AddRectFilled(ImVec2(pos.x, pos.y + 9),
                      ImVec2(knobX, pos.y + 15),
                      IM_COL32(0, 255, 247, 200), 8.0f);
    dl->AddCircleFilled(ImVec2(knobX, cy), 9.0f, IM_COL32(0, 255, 247, 60));
    dl->AddCircleFilled(ImVec2(knobX, cy), 6.0f, IM_COL32(0, 255, 247, 255));
    dl->AddCircleFilled(ImVec2(knobX, cy), 3.0f, IM_COL32(10, 14, 20, 255));

    ImGui::PopID();
    return changed;
}

bool CyberToggle(const char* label, bool* v) {
    if (!v) return false;
    ImGui::PushID(label);

    float w = 52.0f, h = 24.0f, r = h * 0.5f;
    ImVec2 p = ImGui::GetCursorScreenPos();
    ImDrawList* dl = ImGui::GetWindowDrawList();

    static float anim = 0.0f;
    float target = *v ? 1.0f : 0.0f;
    anim = ImLerp(anim, target, 0.20f);

    ImU32 bg = *v
        ? IM_COL32(0, 255, 247, 180)
        : IM_COL32(22, 28, 38, 255);
    dl->AddRectFilled(p, ImVec2(p.x + w, p.y + h), bg, r);

    if (*v) {
        dl->AddRectFilled(p, ImVec2(p.x + w, p.y + h),
                          IM_COL32(0, 255, 247, 60), r);
    }

    float kx = ImLerp(p.x + r, p.x + w - r, anim);
    ImVec2 kc(kx, p.y + r);
    dl->AddCircleFilled(kc, r - 3, IM_COL32(255, 255, 255, 255));
    if (*v)
        dl->AddCircle(kc, r - 1, IM_COL32(0, 255, 247, 255), 0, 1.5f);

    ImGui::InvisibleButton("##tg", ImVec2(w, h));
    if (ImGui::IsItemClicked()) *v = !*v;

    ImGui::SameLine();
    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 3);
    ImGui::TextColored(*v ? CyberTheme::NeonCyan : CyberTheme::TextPri,
                       "%s", label);

    ImGui::PopID();
    return *v;
}

static bool CyberNavButton(const char* label, const char* icon,
                           bool selected, ImVec2 size = ImVec2(0, 52)) {
    if (size.x <= 0) size.x = ImGui::GetContentRegionAvail().x;
    ImDrawList* dl = ImGui::GetWindowDrawList();
    ImVec2 pos = ImGui::GetCursorScreenPos();
    ImVec2 end(pos.x + size.x, pos.y + size.y);

    ImU32 bg = selected
        ? IM_COL32(0, 255, 247, 60)
        : IM_COL32(20, 26, 36, 200);
    dl->AddRectFilled(pos, end, bg, 6.0f);

    ImU32 accent = selected
        ? IM_COL32(0, 255, 247, 255)
        : IM_COL32(80, 90, 110, 180);
    dl->AddRectFilled(pos, ImVec2(pos.x + 3, end.y), accent, 6.0f);

    if (selected)
        dl->AddRect(pos, end, IM_COL32(0, 255, 247, 200), 6.0f, 0, 1.2f);

    ImVec2 iconPos(pos.x + 16, pos.y + 17);
    ImVec2 textPos(pos.x + 44, pos.y + 17);
    ImU32 col = selected
        ? IM_COL32(255, 255, 255, 255)
        : IM_COL32(200, 205, 220, 255);
    dl->AddText(iconPos, col, icon);
    dl->AddText(textPos, col, label);

    ImGui::InvisibleButton(label, size);
    return ImGui::IsItemClicked();
}

//Birthday special source code of free fire mod menu by B-tik 🙏❤️😴
//leaked from india by b-tik on 13th october 11.20 p.m.🗿🌚🥲
//please dont take the credits to and share with my credits brother and sisters 😊❤️🫂

static void DrawFloatingButton(ImDrawList* dl, ImVec2 screenSize) {
    const float btnRadius = 32.0f;
    ImVec2 btnCenter(g_FloatBtnX, g_FloatBtnY);

    
    if (btnCenter.x < btnRadius)                btnCenter.x = btnRadius;
    if (btnCenter.y < btnRadius)                btnCenter.y = btnRadius;
    if (btnCenter.x > screenSize.x - btnRadius) btnCenter.x = screenSize.x - btnRadius;
    if (btnCenter.y > screenSize.y - btnRadius) btnCenter.y = screenSize.y - btnRadius;
    g_FloatBtnX = btnCenter.x;
    g_FloatBtnY = btnCenter.y;

    
    ImGui::SetNextWindowPos(ImVec2(0, 0));
    ImGui::SetNextWindowSize(screenSize);
    ImGui::Begin("##btn_layer", 0,
        ImGuiWindowFlags_NoTitleBar |
        ImGuiWindowFlags_NoResize |
        ImGuiWindowFlags_NoMove |
        ImGuiWindowFlags_NoScrollbar |
        ImGuiWindowFlags_NoSavedSettings |
        ImGuiWindowFlags_NoBackground |
        ImGuiWindowFlags_NoBringToFrontOnFocus);

    ImGui::SetCursorScreenPos(ImVec2(btnCenter.x - btnRadius, btnCenter.y - btnRadius));
    ImGui::InvisibleButton("##floating_btn", ImVec2(btnRadius * 2, btnRadius * 2));

    bool hovered = ImGui::IsItemHovered();
    bool active  = ImGui::IsItemActive();

    
    if (active && !g_FloatDragging) {
        g_FloatDragging = true;
        ImVec2 mouse = ImGui::GetIO().MousePos;
        g_DragOffsetX = btnCenter.x - mouse.x;
        g_DragOffsetY = btnCenter.y - mouse.y;
    }

    
    if (g_FloatDragging && ImGui::IsMouseDown(0)) {
        ImVec2 mouse = ImGui::GetIO().MousePos;
        btnCenter.x = mouse.x + g_DragOffsetX;
        btnCenter.y = mouse.y + g_DragOffsetY;
        g_FloatBtnX = btnCenter.x;
        g_FloatBtnY = btnCenter.y;
    }

    
    if (g_FloatDragging && ImGui::IsMouseReleased(0)) {
        g_FloatDragging = false;
        ImVec2 mouse = ImGui::GetIO().MousePos;
        float dx = mouse.x - btnCenter.x;
        float dy = mouse.y - btnCenter.y;
        float dist = sqrtf(dx * dx + dy * dy);
        if (dist < btnRadius + 10) {
            g_MenuOpen = !g_MenuOpen;
        }
    }

    
    for (int i = 4; i >= 1; --i) {
        dl->AddCircleFilled(btnCenter, btnRadius + i * 2.5f,
                            IM_COL32(0, 255, 247, 20 + i * 10));
    }

    ImU32 bg = g_MenuOpen
        ? IM_COL32(0, 255, 247, 220)
        : IM_COL32(20, 26, 36, 230);
    dl->AddCircleFilled(btnCenter, btnRadius, bg);
    dl->AddCircle(btnCenter, btnRadius, IM_COL32(0, 255, 247, 255), 0, 2.0f);
    dl->AddCircle(btnCenter, btnRadius - 5, IM_COL32(255, 0, 204, 200), 0, 1.5f);

    const char* iconText = "b-tik";
    ImVec2 ts = ImGui::CalcTextSize(iconText);
    ImVec2 tp(btnCenter.x - ts.x * 0.5f, btnCenter.y - ts.y * 0.5f);
    ImU32 tc = g_MenuOpen ? IM_COL32(0, 0, 0, 255) : IM_COL32(0, 255, 247, 255);
    dl->AddText(tp, tc, iconText);

    if (hovered && !g_FloatDragging) {
        dl->AddCircle(btnCenter, btnRadius + 3, IM_COL32(255, 0, 204, 180), 0, 2.0f);
    }

    ImGui::End();
}

//Birthday special source code of free fire mod menu by B-tik 🙏❤️😴
//leaked from india by b-tik on 13th october 11.20 p.m.🗿🌚🥲
//please dont take the credits to and share with my credits brother and sisters 😊❤️🫂

uintptr_t il2cpp_base = 0;
void *getRealAddr(ulong offset) {
    return reinterpret_cast<void*>(il2cpp_base + offset);
}

inline EGLBoolean (*old_eglSwapBuffers)(EGLDisplay dpy, EGLSurface surface);
inline EGLBoolean hook_eglSwapBuffers(EGLDisplay dpy, EGLSurface surface) {
    eglQuerySurface(dpy, surface, EGL_WIDTH,  &g_GlWidth);
    eglQuerySurface(dpy, surface, EGL_HEIGHT, &g_GlHeight);

    if (!g_IsSetup) {
        prevWidth  = g_GlWidth;
        prevHeight = g_GlHeight;
        SetupImgui();
        g_IsSetup = true;
    }

    
    static bool isTouching = false;
    static float touchStartTime = 0.0f;
    ImGuiIO& io = ImGui::GetIO();

    if (Class_Input__get_touchCount && Class_Input__GetTouch) {
        int tc = ((int (*)())(Class_Input__get_touchCount))();
        if (tc > 0) {
            UnityEngine_Touch_Fields touch = ((UnityEngine_Touch_Fields(*)(int))(Class_Input__GetTouch))(0);
            float revY = io.DisplaySize.y - touch.m_Position.fields.y;
            io.MousePos = ImVec2(touch.m_Position.fields.x, revY);
            if (!isTouching) touchStartTime = ImGui::GetTime();
            io.MouseDown[0] = true;
            isTouching = true;
        } else {
            if (isTouching && (ImGui::GetTime() - touchStartTime < 0.06f))
                io.MouseDown[0] = true;
            else {
                UpdateSpeedhack();
                io.MouseDown[0] = false;
                isTouching = false;
            }
        }
    }

    
    mainCamera = Camera_main();

    ApplyCyberTheme();
    ImGui_ImplOpenGL3_NewFrame();
    ImGui_ImplAndroid_NewFrame(g_GlWidth, g_GlHeight);
    ImGui::NewFrame();
    
    if (Enable) {
        BlackSkyUpdate();
        SpoofAllNames();
        UpdateSpinBot();
        AutoKillLogic();
        AntidevAimbotVoid();

        void* match = Curent_Match();
        if (match) {
            void* lp = GetLocalPlayer(match);
            if (lp) {
                UpdateShurikenKill(lp);
                if (LockedEnemy) CustomFireRateLogic(lp, LockedEnemy);
                AimLockLogic(lp, match);
            }
        }
    }

    
    DrawESP(g_GlWidth, g_GlHeight);
    DrawAIMBOT(g_GlWidth, g_GlHeight);

    
    ImDrawList* fgDraw = ImGui::GetForegroundDrawList();
    ImVec2 screenSize((float)g_GlWidth, (float)g_GlHeight);
    DrawFloatingButton(fgDraw, screenSize);
    if (g_MenuOpen) {
        ImGui::SetNextWindowSize(ImVec2(currentWidth, currentHeight), ImGuiCond_Once);
        ImGui::SetNextWindowPos(ImVec2(
            (screenSize.x - currentWidth) * 0.5f,
            (screenSize.y - currentHeight) * 0.5f
        ), ImGuiCond_Once);

        ImGui::Begin("##b_tik_menu", 0,
            ImGuiWindowFlags_NoSavedSettings |
            ImGuiWindowFlags_NoScrollbar |
            ImGuiWindowFlags_NoResize |
            ImGuiWindowFlags_NoTitleBar);

        ImDrawList* dl = ImGui::GetWindowDrawList();
        ImVec2 wp = ImGui::GetWindowPos();
        ImVec2 ws = ImGui::GetWindowSize();

       
        dl->AddRect(wp, ImVec2(wp.x + ws.x, wp.y + ws.y),
                    IM_COL32(0, 255, 247, 120), 10.0f, 0, 1.5f);
        dl->AddRect(ImVec2(wp.x + 2, wp.y + 2),
                    ImVec2(wp.x + ws.x - 2, wp.y + ws.y - 2),
                    IM_COL32(255, 0, 204, 60), 10.0f, 0, 1.0f);

        
        ImVec2 titlePos(wp.x + 16, wp.y + 12);
        dl->AddText(titlePos, IM_COL32(0, 255, 247, 255), "b-tik");
        ImVec2 t2 = ImVec2(titlePos.x + ImGui::CalcTextSize("B-TIK").x + 8, titlePos.y);
        dl->AddText(t2, IM_COL32(255, 0, 204, 255), "//");
        ImVec2 t3 = ImVec2(t2.x + ImGui::CalcTextSize("//").x + 8, titlePos.y);
        dl->AddText(t3, IM_COL32(255, 255, 255, 255), "B-TIK SPECIAL BIRTHDAY SRC");

       
        static float scanX = 0.0f;
        scanX += ImGui::GetIO().DeltaTime * 300.0f;
        if (scanX > ws.x) scanX = 0.0f;
        dl->AddLine(ImVec2(wp.x + scanX, wp.y + 34),
                    ImVec2(wp.x + scanX + 60, wp.y + 34),
                    IM_COL32(0, 255, 247, 200), 1.5f);

     
        ImGui::SetCursorScreenPos(ImVec2(wp.x + ws.x - 36, wp.y + 10));
        ImGui::PushStyleColor(ImGuiCol_Button,        IM_COL32(255, 0, 90, 180));
        ImGui::PushStyleColor(ImGuiCol_ButtonHovered, IM_COL32(255, 0, 90, 255));
        ImGui::PushStyleColor(ImGuiCol_ButtonActive,  IM_COL32(200, 0, 70, 255));
        if (ImGui::Button("X##close", ImVec2(26, 26))) {
            g_MenuOpen = false;
        }
        ImGui::PopStyleColor(3);

        ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 28);

        
        ImGui::BeginChild("nav", ImVec2(190, 0), true);
        ImGui::Spacing();
        if (CyberNavButton("AIMBOT",   ICON_FA_CROSSHAIRS, currentTab == 0)) currentTab = 0;
        ImGui::Spacing();
        if (CyberNavButton("VISUAL",   ICON_FA_EYE,        currentTab == 1)) currentTab = 1;
        ImGui::Spacing();
        if (CyberNavButton("MISC",     ICON_FA_FIRE,       currentTab == 2)) currentTab = 2;
        ImGui::Spacing();
        if (CyberNavButton("FIREWALL", ICON_FA_SHIELD,     currentTab == 3)) currentTab = 3;
        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Spacing();
        ImGui::TextColored(CyberTheme::TextDim, "credits:");
        ImGui::TextColored(CyberTheme::NeonCyan, "b-tik");
        ImGui::EndChild();

        ImGui::SameLine();

        
        ImGui::BeginChild("content", ImVec2(0, 0), true);
        ImGui::Spacing();

        switch (currentTab) {
      
        case 0: {
            ImGui::TextColored(CyberTheme::NeonMagenta, "◆ AIMBOT CONFIG");
            ImGui::Separator();
            ImGui::Spacing();

            CyberToggle("Master Enable",     &Enable);
            CyberToggle("Aimbot",            &Aimbot);
            CyberToggle("Silent Aim",        &SilentAim);
            CyberToggle("Aim Silent",        &AimSilent);
            CyberToggle("Headshot",          &Headshot);
            CyberToggle("Aim Visible Check", &AimVisible2);
            CyberToggle("AimKill",           &AimKill1);
            CyberToggle("AutoKill",          &AutoKill);
            CyberToggle("AimLock",           &AimLock);
            CyberToggle("AimLock Through Wall", &AimLockThroughWall);
            CyberToggle("Custom Fire Rate",  &CustomFireRate);
            CyberToggle("SpinBot",           &SpinBot);
            CyberToggle("Aim Visible (thread)", &aimVisibleEnabled);
            CyberToggle("ANTIDEV",           &ANTIDEV);

            ImGui::Spacing();
            ImGui::Separator();
            ImGui::TextColored(CyberTheme::Amber, "▸ TARGETING");
            CyberSlider("Target FOV",     &Fov_Aim,  0.0f, 360.0f, "%.0f°");
            CyberSlider("Max Distance",   &Aimdis,   0.0f, 500.0f, "%.0f m");
            CyberSlider("Aim Speed",      &AimSpeed, 0.01f, 1.0f, "%.2f");
            CyberSlider("AimKill FOV",    &AimKillFov,   0.0f, 800.0f, "%.0f");
            CyberSlider("AimKill Dist",   &AimKillDistance, 0.0f, 300.0f, "%.0f m");
            CyberSlider("AutoKill Delay", &AutoKillDelayMs, 10.0f, 1000.0f, "%.0f ms");
            CyberSlider("AimLock FOV",    &AimLockFov,   0.0f, 800.0f, "%.0f");
            CyberSlider("AimLock Speed",  &AimLockSpeed, 0.01f, 1.0f, "%.2f");
            CyberSlider("Fire Rate",      &FireRateMs,  20.0f, 1000.0f, "%.0f ms");
            CyberSlider("Shots / Burst",  &ShotsPerBurst, 1.0f, 10.0f, "%.0f");
            CyberSlider("SpinBot Speed",  &SpinBotSpeed, 100.0f, 2000.0f, "%.0f");

            ImGui::Spacing();
            ImGui::TextColored(CyberTheme::Amber, "▸ AIM HEIGHT");
            const char* aimH[] = { "35%", "50%", "75%", "90%", "100%" };
            static int aimHIdx = 4;
            if (ImGui::Combo("##aimh", &aimHIdx, aimH, IM_ARRAYSIZE(aimH))) {
                AimHead35 = (aimHIdx == 0);
                AimHead50 = (aimHIdx == 1);
                AimHead75 = (aimHIdx == 2);
                AimHead90 = (aimHIdx == 3);
                AimHead100 = (aimHIdx == 4);
            }

            ImGui::Spacing();
            ImGui::TextColored(CyberTheme::Amber, "▸ AIM WHEN");
            const char* aimWhen[] = { "Always", "When Firing", "When Scope" };
            static int awIdx = 0;
            if (ImGui::Combo("##aw", &awIdx, aimWhen, IM_ARRAYSIZE(aimWhen)))
                AimWhen = awIdx;

            break;
        }

       
        case 1: {
            ImGui::TextColored(CyberTheme::NeonMagenta, "◆ VISUAL CONFIG");
            ImGui::Separator();
            ImGui::Spacing();

            CyberToggle("ESP Line",        &Config.ESP.Line);
            CyberToggle("ESP Box 2D",      &Config.ESP.Box);
            CyberToggle("ESP Box 3D",      &Config.ESP.Box3d);
            CyberToggle("ESP Box Filled",  &Config.ESP.BoxFilled);
            CyberToggle("ESP Box Half",    &Config.ESP.BoxHalfFilled);
            CyberToggle("Health Bar",      &Config.ESP.Health);
            CyberToggle("Identity Text",   &Config.ESP.MAFIA);
            CyberToggle("Distance Text",   &Config.ESP.Distance);
            CyberToggle("Bone ESP",        &EspSkeleton2);
            CyberToggle("Draw FOV Circle", &DrawFov);
            CyberToggle("Sniper Alert",    &SniperAlert);
            CyberToggle("ESP Grenade",     &ESPGrenade);
            CyberToggle("Night Mode",      &EnableNightMode);

            ImGui::Spacing();
            ImGui::Separator();
            ImGui::TextColored(CyberTheme::Amber, "▸ STYLE");
            CyberSlider("Line Thickness", &LineThickness, 0.5f, 5.0f, "%.1f");
            CyberSlider("Box Thickness",  &BoxThickness,  0.5f, 5.0f, "%.1f");
            CyberSlider("Box Roundness",  &BoxRoundness,  0.0f, 15.0f, "%.1f");

            const char* lineModes[] = { "Bottom", "Middle", "Top", "Left", "Right" };
            static int lm = 0;
            if (ImGui::Combo("Line Mode", &lm, lineModes, IM_ARRAYSIZE(lineModes)))
                LineMode = lm;

            const char* boxStyles[] = {
                "Normal", "Corner", "3D", "Filled", "Dashed",
                "Gradient", "Shadow", "Glow", "Double", "X", "Outline", "HealthBar"
            };
            static int bs = 0;
            if (ImGui::Combo("Box Style", &bs, boxStyles, IM_ARRAYSIZE(boxStyles)))
                BoxStyle = bs;

            break;
        }

        case 2: {
            ImGui::TextColored(CyberTheme::NeonMagenta, "◆ MISC / EXPLOITS");
            ImGui::Separator();
            ImGui::Spacing();

            CyberToggle("Speed Hack",        &SpeedHack);
            CyberToggle("Speed Run",         &speedrun);
            CyberToggle("Fast Switch",       &Fastswitch);
            CyberToggle("Auto Run",          &AutoRun);
            CyberToggle("Infinite Range",    &InfiniteRange);
            CyberToggle("No Recoil",         &norecoil);
            CyberToggle("Sniper Fast",       &SniperFast);
            CyberToggle("PC Swap Anim",      &PcSwapAnim);
            CyberToggle("Set India",         &Setindia);
            CyberToggle("Camera Height",     &camxa);
            CyberToggle("Guest Reset",       &Reset);
            CyberToggle("Free Move",         &FreeMove);
            CyberToggle("Stop Fire Anim",    &StopFireAnim);
            CyberToggle("Parachuting",       &isParachuting);
            CyberToggle("Medkit Moving",     &MedkitMoving);
            CyberToggle("Fast Sensitivity",  &FastSensivity);
            CyberToggle("Quick Reload",      &QuickReloadLakiyaxMods);
            CyberToggle("Shuriken Kill",     &ShurikenKill);
            CyberToggle("Medkit Faster Rate",&FUCKMODI);
            CyberToggle("User Level Spoof",  &LUNDUP);
            CyberToggle("Auto Revive",       &autoReviveEnabled);
            CyberToggle("Glider Hack",       &gliderHackEnabled);
            CyberToggle("Glider Infinite",   &gliderInfiniteEnabled);
            CyberToggle("Spoof Name",        &SpoofNameEnabled);
            CyberToggle("Mass Kill",         &Mass.Sucks);
            CyberToggle("Bypass Login 400",  &g_LoginBypass400);

            ImGui::Spacing();
            ImGui::Separator();
            ImGui::TextColored(CyberTheme::Amber, "▸ VALUES");
            CyberSlider("Speed Multiplier", &active, 0.0f, 5.0f, "%.2f");
            CyberSlider("Mass Kill Range",  &Mass.Sucks1, 1.0f, 30.0f, "%.1f m");
            CyberSlider("Mass Kill Offset", &Mass.FrontOffset, -1.0f, 3.0f, "%.2f");
            CyberSlider("Car Y Offset",     (float*)&DONTCarValue, -20.0f, 20.0f, "%.0f");
            CyberSlider("Sensitivity",      &Sensivity, 0.1f, 10.0f, "%.2f");
            CyberSlider("Medkit Rate",      &FUCKMODIRate, 0.1f, 5.0f, "%.2f");
            CyberSlider("AI FOV",           &AiFov, 0.0f, 180.0f, "%.0f");

            break;
        }

       
        case 3: {
            ImGui::TextColored(CyberTheme::NeonMagenta, "◆ FIREWALL / NETWORK");
            ImGui::Separator();
            ImGui::Spacing();

            ImGui::Checkbox("Enable Firewall", &g_FirewallEnabled);
            ImGui::SameLine();
            ImGui::Checkbox("Verbose Logging", &g_FirewallVerbose);

            ImGui::Spacing();
            ImGui::TextColored(CyberTheme::NeonCyan, "▸ STATUS");
            ImGui::TextColored(g_FwStats.hooksOk ? CyberTheme::Success : CyberTheme::Danger,
                               "Hooks: %d active %s",
                               g_FwStats.libsHooked,
                               g_FwStats.hooksOk ? "[OK]" : "[FAIL]");
            ImGui::Text("Whitelist: %s", FW_ALLOWED_DOMAIN);
            if (strlen(g_fwAllowedIpCache) > 0)
                ImGui::TextColored(CyberTheme::Success, "Cached IP: %s", g_fwAllowedIpCache);
            else
                ImGui::TextColored(CyberTheme::Amber, "Cached IP: (unresolved)");

            ImGui::Spacing();
            ImGui::TextColored(CyberTheme::NeonCyan, "▸ RUNTIME STATS");
            ImGui::TextColored(CyberTheme::TextPri,  "Total Checks : %d", g_FwStats.totalChecks);
            ImGui::TextColored(CyberTheme::Success,  "Total Allowed: %d", g_FwStats.totalAllowed);
            ImGui::TextColored(CyberTheme::Danger,   "Total Blocked: %d", g_FwStats.totalBlocked);
            ImGui::TextColored(CyberTheme::Danger,   "Anogs Blocks : %d", g_FwStats.anogsBlocked);
            ImGui::TextColored(CyberTheme::Danger,   "Domain Blocks: %d", g_FwStats.domainBlocked);
            ImGui::TextColored(CyberTheme::Danger,   "Port Blocks  : %d", g_FwStats.portBlocked);
            ImGui::TextColored(CyberTheme::Danger,   "Priv IP Block: %d", g_FwStats.privIpBlocked);

            ImGui::Spacing();
            ImGui::Text("Blocked Ports: %d | Domains: %d",
                        fw_blocked_ports_count, fw_blocked_domains_count);

            ImGui::Spacing();
            ImGui::Separator();
            ImGui::Spacing();

            if (ImGui::Button("Clear Logs", ImVec2(120, 30))) {
                std::lock_guard<std::mutex> lk(g_fwLogMutex);
                g_fwLogs.clear();
            }
            ImGui::SameLine();
            ImGui::Text("Entries: %d / %d",
                        (int)g_fwLogs.size(), FW_MAX_LOGS);

            ImGui::Spacing();
            ImGui::TextColored(CyberTheme::NeonCyan, "▸ LIVE LOG");

            if (ImGui::BeginChild("fwlog", ImVec2(0, 0), true)) {
                std::lock_guard<std::mutex> lk(g_fwLogMutex);
                if (g_fwLogs.empty()) {
                    ImGui::TextColored(CyberTheme::TextDim, "waiting for traffic...");
                } else {
                    for (auto it = g_fwLogs.rbegin(); it != g_fwLogs.rend(); ++it) {
                        const FW_LogEntry& e = *it;
                        ImVec4 col = e.isBlocked ? CyberTheme::Danger : CyberTheme::Success;
                        ImGui::TextColored(ImVec4(0.6f, 0.6f, 0.7f, 1.0f), "[%s]", e.time.c_str());
                        ImGui::SameLine();
                        ImGui::TextColored(col, "%s", e.isBlocked ? "BLOCK" : "ALLOW");
                        ImGui::SameLine();
                        ImGui::TextColored(CyberTheme::TextPri, "| %s | %s:%s | %s",
                                           e.libName.c_str(),
                                           e.target.c_str(),
                                           e.port.c_str(),
                                           e.reason.c_str());
                    }
                }
            }
            ImGui::EndChild();
            break;
        }
        }

        ImGui::EndChild();
        ImGui::End();
    }

    ImGui::Render();
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
    return old_eglSwapBuffers(dpy, surface);
}


inline void StartGUI() {
    void* ptr = DobbySymbolResolver("/system/lib/libEGL.so", "eglSwapBuffers");
    if (ptr != nullptr) {
        DobbyHook((void*)ptr, (void*)hook_eglSwapBuffers, (void**)&old_eglSwapBuffers);
        LOGD("b-tik GUI: hook OK");
    }
}


void hack_thread() {
    sleep(5);
    pid_t pid = getpid();
    LOGD("b-tik hack_thread started pid=%d", pid);

    do {
        il2cpp_base = get_module_base(pid, "libil2cpp.so");
        sleep(1);
    } while (il2cpp_base == 0);

    LOGD("b-tik il2cpp base: 0x%lx", il2cpp_base);
    Il2CppAttach();

    
    init_firewall();

    
    void* m1 = (void*)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"),
        OBFUSCATE("COW.GamePlay"), OBFUSCATE("NewPlayerAnimationSystemComponent"),
        OBFUSCATE("PlayChangeWeaponAnim"), 2);
    if (m1) DobbyHook(m1, (void*)hook_PlayChangeWeaponAnim, (void**)&orig_PlayChangeWeaponAnim);

    void* m2 = (void*)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"),
        OBFUSCATE("COW"), OBFUSCATE("GameFacade"), OBFUSCATE("ClientUsingVersion"), 0);
    if (m2) DobbyHook(m2, (void*)hook_ClientVersion, (void**)&orig_ClientVersion);

    void* m3 = (void*)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"),
        OBFUSCATE("COW.GamePlay"), OBFUSCATE("Player"), OBFUSCATE("get_InSwapWeaponCD"), 0);
    if (m3) DobbyHook(m3, (void*)_get_InSwapWeaponCD, (void**)&get_InSwapWeaponCD);

    void* m4 = (void*)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"),
        OBFUSCATE("COW.GamePlay"), OBFUSCATE("Player"), OBFUSCATE("get_IsFastRunning"), 0);
    if (m4) DobbyHook(m4, (void*)hook_get_IsFastRunning, (void**)&orig_get_IsFastRunning);

    void* m5 = (void*)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"),
        OBFUSCATE("COW.GamePlay"), OBFUSCATE("UGCLevelPointLight"), OBFUSCATE("get_Range"), 0);
    if (m5) DobbyHook(m5, (void*)hook_get_Range, (void**)&orig_get_Range);

    
    void* mG1 = (void*)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"),
        OBFUSCATE("COW"), OBFUSCATE("GrenadeLine"), OBFUSCATE("Update"), 0);
    if (mG1) DobbyHook(mG1, (void*)_UpdateGranada, (void**)&UpdateGranada);

    void* mG2 = (void*)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"),
        OBFUSCATE("COW"), OBFUSCATE("GrenadeLine"), OBFUSCATE("OnShowGrenadeLineChanged"), 0);
    if (mG2) DobbyHook(mG2, (void*)_UpdateGranada, (void**)&UpdateGranada);

    
    void* mTD = (void*)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"),
        OBFUSCATE("COW.GamePlay"), OBFUSCATE("PlayerNetwork"), OBFUSCATE("TakeDamage"), 9);
    if (mTD) DobbyHook(mTD, (void*)hook_PlayerNetwork_TakeDamage,
                       (void**)&orig_PlayerNetwork_TakeDamage);

    
    void* mSil = (void*)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"),
        OBFUSCATE("COW.GamePlay"), OBFUSCATE("PlayerNetwork"), OBFUSCATE("TakeDamage"), 9);
    if (mSil) DobbyHook(mSil, (void*)BLAGCMCGEJG1, (void**)&old_BLAGCMCGEJG1);

    
    void* mMr = (void*)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"),
        OBFUSCATE("COW.GamePlay"), OBFUSCATE("Player"), OBFUSCATE("SetAimRotation"), 2);
    if (mMr) DobbyHook(mMr, (void*)hook_mrAimSilent, (void**)&orig_mrSilentAim);

    
    void* mFM = (void*)offset_IsFreeMove;
    if (mFM) DobbyHook(mFM, (void*)hook_IsFreeMove, (void**)&old_IsFreeMove);

    
    void* mSF = (void*)offset_PlayStopFire;
    if (mSF) DobbyHook(mSF, (void*)hook_PlayStopFire, (void**)&old_PlayStopFire);

    
    void* mPar = (void*)offset_get_IsParachuting;
    if (mPar) DobbyHook(mPar, (void*)hook_get_IsParachuting, (void**)&orig_get_IsParachuting);

    
    void* mMov = (void*)offset_IsMoving;
    if (mMov) DobbyHook(mMov, (void*)my_IsMoving_Hook_1, (void**)&orig_IsMoving_1);

    
    void* mSens = (void*)offset_GetSensitivity;
    if (mSens) DobbyHook(mSens, (void*)hook_GetSensitivity, (void**)&orig_GetSensitivity);

    
    void* mRel = (void*)offset_GetReloadScale;
    if (mRel) DobbyHook(mRel, (void*)_GetReloadScale, (void**)&orig_GetReloadScale);

    
    void* mMed = (void*)offset_get_FSModeUseMedikitFasterRate;
    if (mMed) DobbyHook(mMed, (void*)my_get_FSModeUseMedikitFasterRate,
                        (void**)&orig_get_FSModeUseMedikitFasterRate);

    
    void* mVeh = (void*)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"),
        OBFUSCATE("message"), OBFUSCATE("ProtoUtil"), OBFUSCATE("PackVector3Pos"), 1);
    if (mVeh) DobbyHook(mVeh, (void*)hook_PackVector3, (void**)&orig_PackVector3);

    
    void* mEmu = (void*)offset_IsEmulator;
    if (mEmu) DobbyHook(mEmu, (void*)_PCcheck, (void**)&PCcheck);

   
    void* mUL = (void*)offset_get_UserLevel;
    if (mUL) DobbyHook(mUL, (void*)_get_UserLevel, (void**)&get_UserLevel);

    
    MemoryPatch::createWithHex((uintptr_t)offset_AntiAddiction_IsAntiAddictActivated,
                               OBFUSCATE("C0 03 5F D6")).Modify();
    MemoryPatch::createWithHex((uintptr_t)offset_AntiAddiction_GetLogMaxAdultsLimit,
                               OBFUSCATE("C0 03 5F D6")).Modify();
    MemoryPatch::createWithHex((uintptr_t)offset_AntiAddiction_GetCurrentPlayedTimeMinutes,
                               OBFUSCATE("C0 03 5F D6")).Modify();
    MemoryPatch::createWithHex((uintptr_t)offset_AntiAddiction_GetRemainingPlayTimeMinutes,
                               OBFUSCATE("C0 03 5F D6")).Modify();

// this bypass is not tested and this would give ban so make your own bypass and add it okk !!!!! 

//Birthday special source code of free fire mod menu by B-tik 🙏❤️😴
//leaked from india by b-tik on 13th october 11.20 p.m.🗿🌚🥲
//please dont take the credits to and share with my credits brother and sisters 😊❤️🫂

//made by b-tik  ! ❤️🥲🙏🗿🫂🌚🎮
    PATCH_LIB("libanogs.so", "0x28ED34", "00 00 80 52 C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x28FD90", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x28EC28", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x295718", "00 00 80 52 C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x295654", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x2C7100", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x2C723C", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x2C7030", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x466EE8", "00 00 80 52 C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x46607C", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x222798", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x222A34", "00 00 80 52 C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x222AC4", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x222BF4", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x222C64", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x22D5D8", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x259150", "00 00 80 52 C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x257F30", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x4B62E4", "00 00 80 52 C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x4B5D18", "00 00 80 52 C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x4B5E28", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x4B6034", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x4B97A4", "00 00 80 52 C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x4A9A0C", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x4A9C88", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x4A9CCC", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x4A9E70", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x4AB264", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x4AB3FC", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x4AB3A4", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x4AB55C", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x4AB60C", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x4AB684", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x47C01C", "00 00 80 52 C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x47C0B8", "00 00 80 52 C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x47C0FC", "00 00 80 52 C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x47C140", "00 00 80 52 C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x1B802C", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x251164", "00 00 80 52 C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x2514AC", "00 00 80 52 C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x468964", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x468A9C", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x284710", "00 00 80 52 C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x4A9600", "00 00 80 52 C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x4A9484", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x1B8C98", "00 00 80 52 C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x1B5AE0", "00 00 80 52 C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x1BD39C", "00 00 80 52 C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x1BAE8C", "00 00 80 52 C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x1B89A8", "00 00 80 52 C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x1BC980", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x1BC9E4", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x1BCA14", "00 00 80 52 C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x1BCDEC", "00 00 80 52 C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x1BC0C0", "00 00 80 52 C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x1B796C", "00 00 80 52 C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x1B25BC", "00 00 80 52 C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x1B3280", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x1B6CCC", "00 00 80 52 C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x1BB1DC", "00 00 80 52 C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x1B5148", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x1B40A0", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x1EC610", "00 00 80 52 C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x1FF8C0", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x1FFCE4", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x284658", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x2C723C", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x2591F8", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x259258", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x28FD90", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x4D9238", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x4D9A00", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x4DA1D4", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x4DDD40", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x4DE640", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x4DEF40", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x4DF840", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x4D9120", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x4D9C3C", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x4DA76C", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x256FBC", "00 00 80 52 C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x257024", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x2C6C7C", "00 00 80 52 C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x284420", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x2845C0", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x2CD8F0", "00 00 80 52 C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x2CD948", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x2CD980", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x2CE0CC", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x2CF998", "00 00 80 52 C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x234284", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x20388C", "00 00 80 52 C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x4FADD0", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x4FAE80", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x4FAE40", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x1C37AC", "00 00 80 52 C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x1C3AD8", "00 00 80 52 C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x1C54B4", "00 00 80 52 C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x1C7864", "00 00 80 52 C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x1C78D0", "00 00 80 52 C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x1C7F5C", "00 00 80 52 C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x1C5A20", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x1C793C", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x1C8264", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x1C61E4", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x1C8884", "00 00 80 52 C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x1C6E40", "00 00 80 52 C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x1C6530", "00 00 80 52 C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x1C7330", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x1C8C0C", "00 00 80 52 C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x1C4114", "00 00 80 52 C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x1C4518", "00 00 80 52 C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x1C4BA4", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x1C4FC8", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x1C8FBC", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x497580", "00 00 80 52 C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x497494", "00 00 80 52 C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x497544", "00 00 80 52 C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x494FFC", "00 00 80 52 C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x4942C4", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x4942D8", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x4ABCE0", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x4E0140", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x4FCD8C", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x45CBEC", "00 00 80 52 C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x465DC4", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x1BDA8C", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x1BD9FC", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x1B9C58", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x4A94BC", "00 00 80 52 C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x4A9544", "00 00 80 52 C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x4A95A0", "00 00 80 52 C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x4ABB14", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x4ABB70", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x4ABBF4", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x4AB9F8", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x4982B0", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x4977F4", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x4976F0", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x497714", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x49755C", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x497A64", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x49836C", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x494450", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x4944E8", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x49456C", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x494588", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x20A774", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x1CFDE8", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x1BE1E0", "C0 03 5F D6");
    PATCH_LIB("libanogs.so", "0x221744", "C0 03 5F D6");
    
    std::thread(StartAutoRevive).detach();
    std::thread(StartGlider).detach();
    std::thread(StartAimbotVisible).detach();

    StartGUI();
    LOGD("b-tik: all hooks installed, GUI started");
}
